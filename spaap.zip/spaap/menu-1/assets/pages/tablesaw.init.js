
/*
Template Name: Codefox - Bootstrap 4 Admin Template
Author: CoderThemes
File: Tablesaw init js
*/

$( function(){
    $( document ).trigger( "enhance.tablesaw" );
});
